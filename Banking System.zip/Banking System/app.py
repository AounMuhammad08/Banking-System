from flask import Flask, render_template, request, redirect, url_for, flash
from bank import Bank

app = Flask(__name__)
app.secret_key = 'your_secret_key'

bank = Bank()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/create_account', methods=['GET', 'POST'])
def create_account():
    if request.method == 'POST':
        try:
            name = request.form['name']
            email = request.form['email']
            phone = request.form['phone']
            balance = float(request.form['balance'])
            bank.create_account(name, email, phone, balance)
            flash("Account created successfully!")
            return redirect(url_for('home'))
        except Exception as e:
            flash(f"Error: {str(e)}")
    return render_template('create_account.html')
@app.route('/deposit', methods=['GET', 'POST'])
def deposit():
    if request.method == 'POST':
        try:
            account_id = int(request.form['account_id'])
            amount = float(request.form['amount'])
            bank.deposit(account_id, amount)
            flash(f"₹{amount} deposited successfully into account {account_id}.")
        except Exception as e:
            flash(f"Error: {str(e)}")  # This will show 'Account not found' if raised
        return redirect(url_for('deposit'))
    return render_template('deposit.html')


@app.route('/withdraw', methods=['GET', 'POST'])
def withdraw():
    if request.method == 'POST':
        try:
            account_id = int(request.form['account_id'])
            amount = float(request.form['amount'])
            bank.withdraw(account_id, amount)
            flash(f"₹{amount} withdrawn successfully from account {account_id}.")
        except Exception as e:
            flash(f"Error: {str(e)}")  # Shows account not found or insufficient funds
        return redirect(url_for('withdraw'))
    return render_template('withdraw.html')


@app.route('/transfer', methods=['GET', 'POST'])
def transfer():
    if request.method == 'POST':
        try:
            sender = int(request.form['sender'])
            receiver = int(request.form['receiver'])
            amount = float(request.form['amount'])
            bank.transfer(sender, receiver, amount)
            flash("Transfer successful!")
        except Exception as e:
            flash(f"Error: {str(e)}")
        return redirect(url_for('transfer'))
    return render_template('transfer.html')

@app.route('/view_accounts')
def view_accounts():
    try:
        accounts = bank.get_all_accounts()
        return render_template('view_accounts.html', accounts=accounts)
    except Exception as e:
        flash(f"Error: {str(e)}")
        return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
