class Account:
    def __init__(self, account_id, customer_id, balance):
        self.account_id = account_id
        self.customer_id = customer_id
        self.balance = balance

    def __repr__(self):
        return f"<Account {self.account_id}: Balance {self.balance}>"
