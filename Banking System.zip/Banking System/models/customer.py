class Customer:
    def __init__(self, customer_id, name, email, phone):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.phone = phone

    def __repr__(self):
        return f"<Customer {self.name} ({self.customer_id})>"
