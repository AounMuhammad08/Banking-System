from decimal import Decimal
import mysql.connector

class Bank:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Muh@mmadhacci125",
            database="bank_db"
        )
        self.cursor = self.conn.cursor(dictionary=True)

    def create_account(self, name, email, phone, balance):
        balance = Decimal(str(balance))
        self.cursor.execute("INSERT INTO customers (name, email, phone) VALUES (%s, %s, %s)", (name, email, phone))
        customer_id = self.cursor.lastrowid
        self.cursor.execute("INSERT INTO accounts (customer_id, balance) VALUES (%s, %s)", (customer_id, balance))
        account_id = self.cursor.lastrowid
        self.cursor.execute("INSERT INTO transactions (account_id, amount, transaction_type) VALUES (%s, %s, 'deposit')",
                            (account_id, balance))
        self.conn.commit()

    def deposit(self, account_id, amount):
        cursor = self.conn.cursor()
        cursor.execute("SELECT balance FROM accounts WHERE account_id = %s", (account_id,))
        result = cursor.fetchone()
        if not result:
            raise Exception("Account not found.")
        current_balance = result[0]
        amount = Decimal(str(amount))
        new_balance = current_balance + amount
        cursor.execute("UPDATE accounts SET balance = %s WHERE account_id = %s", (new_balance, account_id))
        cursor.execute("INSERT INTO transactions (account_id, transaction_type, amount) VALUES (%s, 'deposit', %s)", (account_id, amount))
        self.conn.commit()

    def withdraw(self, account_id, amount):
        self.cursor.execute("SELECT balance FROM accounts WHERE account_id = %s", (account_id,))
        account = self.cursor.fetchone()
        if not account:
            raise Exception("Account not found.")
        balance = account['balance']
        amount = Decimal(str(amount))
        if balance < amount:
            raise Exception("Insufficient funds.")
        self.cursor.execute("UPDATE accounts SET balance = balance - %s WHERE account_id = %s", (amount, account_id))
        self.cursor.execute("INSERT INTO transactions (account_id, transaction_type, amount) VALUES (%s, 'withdraw', %s)",
                            (account_id, amount))
        self.conn.commit()

    def transfer(self, sender_id, receiver_id, amount):
        amount = Decimal(str(amount))
        self.cursor.execute("SELECT balance FROM accounts WHERE account_id = %s", (sender_id,))
        sender = self.cursor.fetchone()
        if not sender:
            raise Exception("Sender account not found.")
        if sender['balance'] < amount:
            raise Exception("Insufficient funds for transfer.")

        self.cursor.execute("SELECT balance FROM accounts WHERE account_id = %s", (receiver_id,))
        receiver = self.cursor.fetchone()
        if not receiver:
            raise Exception("Receiver account not found.")

        self.cursor.execute("UPDATE accounts SET balance = balance - %s WHERE account_id = %s", (amount, sender_id))
        self.cursor.execute("UPDATE accounts SET balance = balance + %s WHERE account_id = %s", (amount, receiver_id))
        self.cursor.execute("INSERT INTO transactions (account_id, transaction_type, amount) VALUES (%s, 'transfer', %s)", (sender_id, amount))
        self.cursor.execute("INSERT INTO transactions (account_id, transaction_type, amount) VALUES (%s, 'deposit', %s)", (receiver_id, amount))
        self.conn.commit()

    def get_all_accounts(self):
        self.cursor.execute("""
            SELECT a.account_id, c.name, c.email, a.balance
            FROM accounts a
            JOIN customers c ON a.customer_id = c.customer_id
        """)
        return self.cursor.fetchall()
