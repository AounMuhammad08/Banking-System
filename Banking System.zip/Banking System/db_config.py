import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Muh@mmadhacci125",
        database="bank_db"
    )
